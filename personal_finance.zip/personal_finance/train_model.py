# %% train_model.py
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
import joblib
import os

# Ensure models directory exists
os.makedirs('models', exist_ok=True)

# Example data (replace with your actual data if available)
data = pd.DataFrame({
    'month': [1, 2, 3, 4, 5, 6],
    'income': [5000, 5200, 5100, 5300, 5500, 5600],
    'expenses': [3000, 3100, 3200, 3300, 3400, 3500]
})

# Features and target
X = data[['income', 'month']]
y = data['expenses']

# Train the model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X, y)

# Save the model
model_file_path = 'models/expense_model.pkl'
joblib.dump(model, model_file_path)

print(f"Model saved as '{model_file_path}'")

# %%
