# %% app.py
from flask import Flask, render_template, request, jsonify
import pandas as pd
import joblib
import os
import plotly.express as px

app = Flask(__name__)

# File paths
DATA_FILE = "data/user_data.csv"
MODEL_FILE = "models/expense_model.pkl"

# Ensure directories exist
os.makedirs("data", exist_ok=True)

# Load the model
def load_model():
    if not os.path.exists(MODEL_FILE):
        raise FileNotFoundError("Model file not found! Please train the model by running 'train_model.py'.")
    return joblib.load(MODEL_FILE)

model = load_model()

# Load user data
def load_data():
    if os.path.exists(DATA_FILE):
        # Load the CSV file
        data = pd.read_csv(DATA_FILE)
        
        # Map your data columns to expected names
        data = data.rename(columns={
            "Category": "category",       # Map 'Category' to 'category'
            "Debit/Credit": "amount",    # Map 'Debit/Credit' to 'amount'
            "Income/Expense": "type"     # Map 'Income/Expense' to 'type'
        })
        
        # Ensure amounts are positive and only necessary columns are included
        data["amount"] = data["amount"].abs()  # Make all amounts positive
        data = data[["category", "amount", "type"]]
        
        return data
    else:
        # Return an empty DataFrame with the required structure
        return pd.DataFrame(columns=["category", "amount", "type"])

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    data = load_data()
    if request.method == 'POST':
        income = float(request.form['income'])
        month = int(request.form['month'])
        prediction = model.predict([[income, month]])[0]
        return render_template(
            'dashboard.html',
            prediction=round(prediction, 2),
            data=data.to_dict(orient='records')
        )
    return render_template('dashboard.html', data=data.to_dict(orient='records'))

@app.route('/visualize')
def visualize():
    data = load_data()
    if data.empty:
        return render_template('visualize.html', error="No data available to visualize.")
    
    # Filter to include only expenses
    expense_data = data[data["type"] == "Expense"]
    
    # Group by category and calculate totals
    pie_data = expense_data.groupby("category")["amount"].sum().reset_index()
    
    # Create the pie chart using Plotly
    fig = px.pie(pie_data, values="amount", names="category", title="Expense Breakdown", hole=0.4)
    fig.update_traces(textinfo="percent+label")
    
    # Convert the figure to an HTML representation
    graph = fig.to_html(full_html=False)
    
    return render_template("visualize.html", graph=graph)

@app.route('/save_data', methods=['POST'])
def save_data():
    data = request.get_json()
    df = load_data()
    new_data = pd.DataFrame(data)
    updated_data = pd.concat([df, new_data], ignore_index=True)
    updated_data.to_csv(DATA_FILE, index=False)
    return jsonify({'message': 'Data saved successfully!'})

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)
